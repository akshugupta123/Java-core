/**
 * 
 */
/**
 * @author Akshatha
 *
 */
module JavaHandsonMasterys1day2 {
}